﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainController : MonoBehaviour
{
    public Rotate rotatescript;
    public Spawner spawnerscript;
    public SimpleMove movescript;
    public GameObject cylindertoinvis_obj;
    public MeshRenderer cylindertoinvis_obj_rend;
    public AudioSource musictoplay;
    public Camera camtocontrol;
    public Color backColor;
    public Light light1;
    public TextMesh textObject;

    void Start()
    {
        light1.color = backColor;
        textObject.text = "HelloWorld";
        //rotatescript.rotateSpeed = 180f; this code makes the cube rotate at a set speed.
        //spawnerscript.SpawnObject(); this code spawns an object.
    }
    //create a timer to manage
    //float textTimer = 0; 

    void Update()
    {
        RotationControl();
        SpawnerControl();
        MoveControl();
        CylinderControl();
        MusicControl();
        CamBackgroundControl();

        //create it from Time.deltaTime
        //textTimer += Time.deltaTime;
    }


    void RotationControl()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1) && rotatescript.rotateSpeed == 0f)
        {
            rotatescript.rotateSpeed = 180f;
        }

        else if (Input.GetKeyDown(KeyCode.Alpha1) && rotatescript.rotateSpeed >= 1f)
        {
            rotatescript.rotateSpeed = 0f;
        }
    }


    void SpawnerControl()
    {
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            spawnerscript.SpawnObject();
        }
        else
        {

        }
    }

    void MoveControl()
    {
        if (Input.GetKeyDown(KeyCode.Alpha3) && movescript.moveSpeed == 0f)
        {
            movescript.moveSpeed = 4f;
        }
        else if (Input.GetKeyDown(KeyCode.Alpha3) && movescript.moveSpeed >= 1f)
        {
            movescript.moveSpeed = 0f;
        }

    }

    void CylinderControl()
    {
        if (Input.GetKeyDown(KeyCode.Alpha4) && cylindertoinvis_obj.activeSelf == true)
        {
            cylindertoinvis_obj.SetActive(false);
        }
        else if (Input.GetKeyDown(KeyCode.Alpha4) && cylindertoinvis_obj.activeSelf == false)
        {
            cylindertoinvis_obj.SetActive(true);
        }
    }

    // this is a second way, to turn of the renderer for a gameobject.
    void CylinderRender()
    {
        if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            cylindertoinvis_obj_rend.enabled = false;
        }
        else if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            cylindertoinvis_obj_rend.enabled = true;
        }
    }

    void MusicControl()
    {

        if (Input.GetKeyDown(KeyCode.Alpha5) && musictoplay.isPlaying == false)
        {
            musictoplay.Play();
        }
        else if (Input.GetKeyDown(KeyCode.Alpha5) && musictoplay.isPlaying == true)
        {
            musictoplay.Stop();
        }

    }

    bool backgroundFlag = true;
    void CamBackgroundControl(){
        //camtocontrol.backgroundColor = Color.magenta;

        if (Input.GetKeyDown(KeyCode.Alpha6) && backgroundFlag == false)
        {
            camtocontrol.backgroundColor = backColor;
            backgroundFlag = true;
        }
        else if (Input.GetKeyDown(KeyCode.Alpha6) && backgroundFlag == true)
        {
            Color randColor = new Color();
            randColor.r = Random.Range(0, 1f);
            randColor.g = Random.Range(0, 1f);
            randColor.b = Random.Range(0, 1f);

            camtocontrol.backgroundColor = randColor;
            backgroundFlag = false;
        }

    }








}
