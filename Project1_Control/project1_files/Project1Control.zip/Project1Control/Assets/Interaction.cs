﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Interaction : MonoBehaviour
{

    private Renderer rend;

    public Color col;
    private Color newColor;
    private Color startColor;

    // Use this for initialization
    void Start()
    {
        rend = GetComponent<Renderer>();
        startColor = rend.material.color;
        newColor = new Color(Random.value, Random.value, Random.value, 1.0f);
            
    }

    void OnMouseEnter()
    {
        rend.material.color = col;
    }

    void OnMouseExit()
    {
        rend.material.color = newColor;
    }

    void OnMouseOver()
    {
        if (Input.GetMouseButton(0))
        {
            transform.localScale += new Vector3(0.01f, 0.01f, 0.01f);
        }
        else if (Input.GetMouseButton(1))
        {
            transform.localScale -= new Vector3(0.01f, 0.01f, 0.01f);
        }
        else
        {
            transform.localScale = new Vector3(1, 1, 1);
        }
    }

}