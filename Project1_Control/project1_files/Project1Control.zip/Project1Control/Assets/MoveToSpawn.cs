﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveToSpawn : MonoBehaviour {

    private Renderer rend;

    public Color col;
    private Color newColor;
    private Color startColor;
    public Camera cam;
    public GameObject spawn;

    int numberSpawned = 0;

    // Use this for initialization
    void Start()
    {
        rend = GetComponent<Renderer>();
        startColor = rend.material.color;
        newColor = new Color(Random.value, Random.value, Random.value, 1.0f);

    }

    private void Update()
    {
        if (Input.GetMouseButton(0))
        {
            print(Input.mousePosition);
            Vector3 spawnPosition;
            Vector3 screenPosition = Vector3.zero;

            //if (Input.GetMouseButton(0)) {
            screenPosition.x = Input.mousePosition.x;
            screenPosition.y = Input.mousePosition.y;
            screenPosition.z = -cam.transform.position.z;
            //Debug.Log(Camera.main.ScreenToWorldPoint(screenPosition));

            spawnPosition = cam.ScreenToWorldPoint(screenPosition);

            GameObject child = Instantiate(spawn, spawnPosition, Quaternion.identity);
            child.name = "SphereClone" + numberSpawned;
            numberSpawned++;
        }
        else if (Input.GetMouseButton(1))
        {
            transform.localScale -= new Vector3(0.01f, 0.01f, 0.01f);
        }
        else
        {
            transform.localScale = new Vector3(1, 1, 1);
        }
    }

    void OnMouseEnter()
    {
        rend.material.color = col;
    }

    void OnMouseExit()
    {
        rend.material.color = newColor;
    }

    void OnMouseOver()
    {
        
    }

}